<?php
$conn = mysqli_connect('localhost','root','','Library') or die('connection failed');
?>