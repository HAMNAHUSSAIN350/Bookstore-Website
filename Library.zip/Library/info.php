<section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-lg-3 info-col">
          <div class="info_detail">
            <h4>
              About Us
            </h4>
            <p>
            Welcome to Bostorek Bookstore , a haven for book lovers. Founded in 1997, we're dedicated to fostering a community of readers and promoting literacy"
            </p>
            <div class="info_social">
              <a href="https://www.linkedin.com/in/hamna-hussain-815a26325?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app">
                <i class="fa fa-linkedin" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 info-col">
          <div class="info_contact">
            <h4>
              Address
            </h4>
            <div class="contact_link_box">
              <a href="https://maps.app.goo.gl/a2JMnh1pyjefjTLD9">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
                <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +01 1234567890
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  Hamna@gmail.com
                </span>
              </a>
            </div>
          </div>
         </div>
        <div class="col-md-6 col-lg-3 info-col">
          <div class="map_container">
            <div class="map">
              <iframe 
              width="600" 
              height="450" 
               src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9352.072521740694!2d73.69287618885843!3d31.4463802110573!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39188fbfff7dac53%3A0x89e1beb7dbb14e70!2sChughtai%20library!5e0!3m2!1sen!2s!4v1737306400704!5m2!1sen!2s"
              frameborder="0" 
              style="border:0" 
              allowfullscreen>
            </iframe>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 info-col">
          <div class="pages_container">
          <h4>
             Pages
            </h4> 
            <div class="pages_link_box">
              <a href="about.php">
                <span>
                  About
                </span>
              </a>
                <a href="products.php">
                <span>
                 Products
                </span>
              </a>
              <a href="contact.php">
                <span>
                  Contact Us
                </span>
              </a>
              <a href="cart.php">
                <span>
                  Cart
                </span>
              </a>
              <a href="checkout.php">
                <span>
                  Checkout
                </span>
              </a>
            </div>
      </div>
    </div>
    </div>
    </div>
  </section>
